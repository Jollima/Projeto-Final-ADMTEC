	package app;

	import java.sql.SQLException;
import java.util.Scanner;

import model.DeleteDados;
import model.InsertDados;
import model.SelectDados;
import model.SelectPorUmCpf;
import model.UpdateDados;

	public class App {

	public static void main(String[] args) throws SQLException{
		
		Scanner leia = new Scanner(System.in);
		
		char opcao = 'w';
		
		System.out.println("Digite uma das opções abaixo: \n");
		
		System.out.println(
				
		"0 - para encerrar o menu: \n" +
		"1 - Realizar cadastro: \n" + 
		"2 - Realizar pedido: \n" + 
		"3 - Visualizar cardápio: \n" + 
		"4 - Pesquisar os dados do cliente pelo cpf: \n" + 
		"5 - Pesquisar todos os pedidos: \n" +
		"6 - Pesquisar os dados do pedido pelo id: \n" +
		"7 - Alterar dados pedido: \n" + 
		"8 - Visualizar todos os clientes: \n" + 
		"9 - Deletar pedido: \n"
		);
		
		opcao = leia.next().charAt(0);
		
		//Digitar zero pra encerrar
		while(opcao != '0') {
			
			if(opcao == '1') { //Metodo para cadastrar cliente;
				
				String cpf;
				String nome;
				String email;
				String telefone;
				
				System.out.println("Digite o cpf: ");
				cpf = leia.next();
				
				System.out.println("Digite o nome: ");
				nome = leia.next();
				
				System.out.println("Digite o email: ");
				email = leia.next();
				
				System.out.println("Digite o telefone: ");
				telefone = leia.next();
				
				InsertDados.insertDadosCliente(cpf, nome, email, telefone); 
			}
			
			if(opcao == '2') { //Metodo para realizar pedido
				
				String cliente_cpf;
				int produtoId;
				int quantidade;
				
				
				System.out.println( "Digite o seu cpf: ");
				cliente_cpf = leia.next();
				
				System.out.println("Digite o código do produto: ");
				produtoId = leia.nextInt();
				
				System.out.println("Digite a quantidade desejada: ");
				quantidade = leia.nextInt();
				
				InsertDados.insertDadosPedido(cliente_cpf, produtoId, quantidade);
				
				
			}
			
			if(opcao == '3') { //Método para pesquisar e imprimir o cardápio;
				
				SelectDados.findProdutosAll();
			}
			
			
			if(opcao == '4') { //Método para pesquisar os dados do cliente pelo CPF;
				
				String cpf;
				System.out.println("Digite o número do cpf: ");
				cpf = leia.next();
				
				SelectPorUmCpf.selectPorCpf(cpf);
			}
			
			if(opcao == '5') { //Método para visualizar todos os pedido;
				
				SelectDados.findPedidosAll();
			}
			
			if(opcao == '6') { //Método para visualizar o pedido feito;
				
				int id;
				System.out.println("Digite o código do pedido: ");
				id = leia.nextInt();
				
				SelectPorUmCpf.selectPorUmId(id);
			}
			
			if(opcao == '7') { //Metodo para atualizar dados do pedido
				
				String cliente_cpf;
				int produtoId;
				int quantidade;
				int id;
				
				
				System.out.println( "Digite o seu cpf: ");
				cliente_cpf = leia.next();
				
				System.out.println("Digite o código do produto: ");
				produtoId = leia.nextInt();
				
				System.out.println("Digite a quantidade desejada: ");
				quantidade = leia.nextInt();
				
				System.out.println("Informe o ID do pedido: ");
				id = leia.nextInt();
				
				UpdateDados.alterarDadosPedido(cliente_cpf, produtoId, quantidade, id);
				
				
			}
			
			if(opcao == '8') { //Método para visualizar todos os clientes;
				
				SelectDados.findClientesAll();
			}
			
			if(opcao == '9') { //Método para deletar pedido pelo Id;
				
				int id;
				System.out.println("Digite o código do pedido: ");
				id = leia.nextInt();
				
				DeleteDados.excluirDadosPedido(id);
			}
			
			System.out.println("Digite uma das opções abaixo: \n");
			
			System.out.println("0 - para encerrar o menu: \n" +
			
			"1 - Realizar cadastro: \n" + 
			"2 - Realizar pedido: \n" + 
			"3 - Visualizar cardápio: \n" + 
			"4 - Pesquisar os dados do cliente pelo cpf: \n" + 
			"5 - Pesquisar todos os pedidos: \n" +
			"6 - Pesquisar os dados do pedido pelo id: \n" +
			"7 - Alterar pedido: \n" + 
			"8 - Visualizar todos os clientes: \n" + 
			"9 - Deletar pedido: \n"
			);
			
			opcao = leia.next().charAt(0);
			
		}

	}

}
