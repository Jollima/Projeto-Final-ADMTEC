	package model;

	import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import db.DB;

	public class UpdateDados {

	
	public static void alterarDadosCliente( String nome, String email, String telefone, String cpf) {
		
		String sql = "UPDATE clientes SET nome = ?, email = ?, telefone = ? WHERE cpf = ?";
		Connection conexao = DB.getConnection();
		PreparedStatement stmt = null;
		
		try {
			stmt = conexao.prepareStatement(sql);
			
			stmt.setString(1, nome); 
			stmt.setString(2, email);
			stmt.setString(3, telefone);
			stmt.setString(4, cpf);
			stmt.executeUpdate();
			
			stmt.close();
			conexao.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}
	}
	
	public static void alterarDadosPedido(String clienteCpf, int produtoid, int quantidade, int id) {
		
		String sql = "UPDATE pedidos SET clientes_cpf = ?, produto_id = ?, quantidade = ? WHERE id = ?";
		Connection conexao = DB.getConnection();
		PreparedStatement stmt = null;
		
		try {
			stmt = conexao.prepareStatement(sql);
			stmt.setString(1, clienteCpf);
			stmt.setInt(2, produtoid);
			stmt.setInt(3, quantidade);
			stmt.setInt(4, id);
			stmt.executeUpdate();
			
			stmt.close();
			conexao.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}
	}
}
