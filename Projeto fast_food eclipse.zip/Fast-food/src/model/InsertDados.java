package model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import db.DB;

	public class InsertDados {

	public static void insertDadosCliente(String cpf, String nome, String email, String telefone) {
		
		Connection conexao = DB.getConnection();
		
		String sql = "INSERT INTO clientes (cpf, nome, email, telefone)" 
		+ "VALUES (?,?,?,?)";
		
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			stmt.setString(1, cpf);
			stmt.setString(2, nome);
			stmt.setString(3, email);
			stmt.setString(4, telefone);
			
			stmt.execute();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}
	}
	
	public static void insertDadosPedido(String clienteCpf, int produtoid, int quantidade) {
		
		Connection conexao = DB.getConnection();
		
		String sql = "INSERT INTO pedidos (clientes_Cpf, produto_id, quantidade)" 
		+ "VALUES (?,?,?)";
		
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			
			//stmt.setInt(1, id);
			//stmt.setString(2, dataPedido);
			stmt.setString(1, clienteCpf);
			stmt.setInt(2, produtoid);
			stmt.setInt(3, quantidade);
			//stmt.setInt(5, statusPedido);
			
			stmt.execute();
		}
		
		catch(SQLException e){
			throw new RuntimeException(e);
		}
	}
}
