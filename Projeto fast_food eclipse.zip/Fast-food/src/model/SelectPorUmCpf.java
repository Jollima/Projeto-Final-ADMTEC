	package model;

	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.text.SimpleDateFormat;
	import java.util.Date;

	import db.DB;

	public class SelectPorUmCpf {
	
	
	public static void selectPorCpf(String cpf) {
		
		Connection conexao = DB.getConnection();
		String sql = "SELECT * FROM clientes WHERE cpf = ?";
		
		
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			stmt.setString(1, cpf);
			
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				
				String nome = rs.getString("nome");
				String email = rs.getString("email");
				String telefone = rs.getString("telefone");
				
				System.out.println();
				
				System.out.println("NOME: " + nome);
				System.out.println("EMAIL: " + email);
				System.out.println("TELEFONE: " + telefone);
			
				System.out.println();
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void selectPorUmId(Integer id) {
		
		Connection conexao = DB.getConnection();
		String sql = "SELECT * FROM pedidos WHERE id = ?";
		
		
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			stmt.setInt(1, id);
			
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				
				//Date data_pedidos = rs.getDate("data_pedidos");
				String clientes_cpf = rs.getString("clientes_cpf");
				Integer produto_id = rs.getInt("produto_id");
				Integer quantidade = rs.getInt("quantidade");
				
				System.out.println();
				
				//System.out.println("DATA DO PEDIDO: " + data_pedidos);
				System.out.println("CPF DO CLIENTE: " + clientes_cpf);
				System.out.println("CÓDIGO DO PRODUTO: " + produto_id);
				System.out.println("QUANTIDADE: " + quantidade);
			
				System.out.println();
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
