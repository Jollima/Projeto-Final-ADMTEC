	package model;

	import java.sql.Connection;
	import java.sql.Date;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.sql.Statement;
	import java.util.ArrayList;
	import java.util.List;

	import db.DB;

	public class SelectDados {

	
	public static void findClientesAll() throws SQLException {
		
		Connection conexao = DB.getConnection();
		
		String sql = "SELECT * FROM clientes";
		
		Statement stmt = conexao.createStatement();
		
		ResultSet rs = stmt.executeQuery(sql);
		
		
		while(rs.next()) {
			
			String nome = rs.getString("nome");
			String cpf = rs.getString("cpf");
			String email = rs.getString("email");
			String telefone = rs.getString("telefone");
			
			
			System.out.println();
			
			System.out.println("NOME: " + nome);
			System.out.println("CPF: " + cpf);
			System.out.println("EMAIL: " + email);
			System.out.println("TELEFONE: " + telefone);
			
		}
	}//FIm do primeiro método
	
	
	public static void findPedidosAll() throws SQLException {
		
		Connection conexao = DB.getConnection();
		
		String sql = "SELECT * FROM pedidos";
		
		Statement stmt = conexao.createStatement();
		
		ResultSet rs = stmt.executeQuery(sql);
		
		
		while(rs.next()) {
			
			Integer id = rs.getInt("id");
			//Date data_pedidos = rs.getDate("data_pedidos");
			String clientes_cpf = rs.getString("clientes_cpf");
			String produto_id = rs.getString("produto_id");
			Integer quantidade = rs.getInt("quantidade");
			
			
			
			System.out.println();
			
			System.out.println("id: " + id);
			//System.out.println("DATA DO PEDIDO: " + data_pedidos);
			System.out.println("CPF DO CLIENTE: " + clientes_cpf);
			System.out.println("ID DO PRODUTO: " + produto_id);
			System.out.println("QUANTIDADE: " + quantidade);
			
			System.out.println();
		}
	}
	
	public static void findProdutosAll() throws SQLException {
		
		Connection conexao = DB.getConnection();
		
		String sql = "SELECT * FROM produto";
		
		Statement stmt = conexao.createStatement();
		
		ResultSet rs = stmt.executeQuery(sql);
		
		
		while(rs.next()) {
			
			Integer id = rs.getInt("id");
			String nome_produto = rs.getString("nome_produto");
			String descricao = rs.getString("descricao");
			double preco_produto = rs.getDouble("preco_produto");
			
			System.out.println();
			
			System.out.println("CÓDIGO: " + id);
			System.out.println("NOME: " + nome_produto);
			System.out.println("DESCRIÇÃO: " + descricao);
			System.out.println("PREÇO: " + preco_produto);
			
			System.out.println();
		}
	}
	
	public static List<String> findClientesList(){
		List <String> listaClientes = new ArrayList<>();
		
		Connection conn = DB.getConnection();
		String sql = "SELECT * FROM clientes";
		Statement stmt = null;
		ResultSet resultado = null;
		
		try {
			stmt = conn.createStatement();
			resultado = stmt.executeQuery(sql);
			
			while(resultado.next()) {
				listaClientes.add(resultado.getString("cpf"));
				listaClientes.add(resultado.getString("nome"));
				listaClientes.add(resultado.getString("email"));
				listaClientes.add(resultado.getString("telefone"));
				listaClientes.add(resultado.getString("data_nascimento"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return listaClientes;
		
	}
}
