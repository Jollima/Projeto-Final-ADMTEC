	package model;
	
	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.SQLException;

	import db.DB;

	public class DeleteDados {

	
	public static void excluiDadosClientes(String valorDoCpf) {
		
		String sql = "DELETE FROM clientes WHERE cpf = ?";
		
		Connection conexao = DB.getConnection();
		PreparedStatement stmt = null;
		
		try {
			stmt = conexao.prepareStatement(sql);
			stmt.setString(1, valorDoCpf);
			stmt.execute();
			
			stmt.close();
			conexao.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}
	}
	
	public static void excluirDadosPedido(Integer valorId) {
		
		String sql = "DELETE FROM pedidos WHERE id = ?";
		
		Connection conexao = DB.getConnection();
		PreparedStatement stmt = null;
		
		try {
			stmt = conexao.prepareStatement(sql);
			stmt.setInt(1, valorId);
			stmt.execute();
			
			stmt.close();
			conexao.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}
	}
}
