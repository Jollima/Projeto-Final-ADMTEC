package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DB {

	static Connection conexao;
	
	public static Connection getConnection() {
		final String URL = "jdbc:mysql://localhost/fast_food";
		final String USER = "root";
		final String PASSWORD = "";
		
		try {
			return DriverManager.getConnection(URL, USER, PASSWORD);
		} catch (SQLException e) {
			// TODO: handle exception
			throw new RuntimeException(e);
		}
	}
}
